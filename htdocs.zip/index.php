<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    
    <!--OWL coursel-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha256-UhQQ4fxEeABh4JrcmAJ1+16id/1dnlOEVCFOxDef9Lw=" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" integrity="sha256-kksNxjDRxd/5+jGurZUJd1sdR2v+ClrCl3svESBaJqw=" crossorigin="anonymous" />
    <!--Boostrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" integrity="sha256-h20CPZ0QyXlBuAw7A+KluUYx/3pK+c7lYEpqLTlxjYQ=" crossorigin="anonymous" />
    <?php require("functions.php"); ?>
    <?php 
$products_shuffle=$product->getData();
$shufle=shuffle($products_shuffle);
?>

    
    <title>J&M Books</title>
</head>
<body>
    <div class="header">
        <a href="#default" class="logo">J&M Books</a>
        <div class="header-right">
            <a class="active" href="#home">Home</a>
            <a href="Pages/about.php">About</a>
            <?php
            if(isset($_SESSION["formuname"])){
                echo '<a href="Pages/profile.php">Profile</a>';
            }
            else if(isset($_SESSION["formemail"])){
                echo '<a href="Pages/profile.php">Profile</a>';
            }
            else{
                echo '<a href="Pages/register_page.php">Sign Out / In</a>';
            }
            ?>
        </div>
    </div>
    <section id="banner-area">
    <div class="owl-carousel owl-theme">
      <div class="item">
        <img src="assets/Banner1.png" alt="Banner1">
      </div>
      <div class="item">
        <img src="assets/Banner2.png" alt="Banner2">
      </div>
      <div class="item">
        <img src="assets/Banner1.png" alt="Banner3">
      </div>
    </div>
  </section>
<!--Top sales-->
  


<section id="top-sale">
  <div class="container py-5">
    <h4 class="font-rubik font-20">Top Sales</h4>
    <hr>
    <!--owl-->
    
    <div class="owl-carousel owl-theme">
        
      <?php foreach($products_shuffle as $item){ ?>
      <div class="item py-2">
        <div class="product font-rale">
          <a href="product.php?item_id=<?php echo $item['item_id']; ?>"><img src="<?php echo $item['item_image'];?>" alt="product1" class="img-fluid"></a>
          <div class="text-center">
            
            <h6><?php echo $item['item_name'];?></h6>
            <div class="rating text-warning font-size-12">
              <span><i class="fas fa-star"></i></span>
              <span><i class="fas fa-star"></i></span>
              <span><i class="fas fa-star"></i></span>
              <span><i class="fas fa-star"></i></span>
              <span><i class="far fa-star"></i></span>
            </div>
            <div class="price py-2">
              <span><?php echo $item['item_price']??'Unknown'; ?></span>
            </div>
            <button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
          </div>
        </div>
        
        </div> 
        <?php } ?>
        
        
      
      
      
      </div>
      

    <!--#owl-->
  </div>
</section>
    <!--#Top sales-->

    <?php 
$brand=array_map(function($pro){ return $pro['item_brand'];},$products_shuffle);
$uniqe=array_unique($brand);
sort($uniqe);
$shufle=shuffle($products_shuffle);
?>

<section id="special-price">
            <div class="container">
              <h4 class="font-rubik font-size-20">Special Price</h4>
              <div id="filters" class="button-group text-right font-baloo font-size-16">
                <button class="btn is-checked" data-filter="*">All Brand</button>
                <button class="btn" data-filter=".Fantastika">Fantastika</button>
                <button class="btn" data-filter=".Prica">Prica</button>
                <button class="btn" data-filter=".Triler">Triler</button>
                <button class="btn" data-filter=".Horor">Horor</button>
              </div>

              <div class="grid">
                <?php array_map(function($item){ ?>
                <div class="grid-item border <?php echo $item['item_brand'] ??"Brand"; ?>">
                 <div class="item py-2" style="width: 200px;">
                  <div class="product font-rale">
                    <a href="product.php?item_id=<?php echo $item['item_id']; ?>"><img src="<?php echo $item['item_image'] ?? "./assets/product/13.png"; ?>" alt="product1" class="img-fluid"></a>
                    <div class="text-center">
                      <h6><?php echo $item['item_name']??"Unknow"; ?></h6>
                      <div class="rating text-warning font-size-12">
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="fas fa-star"></i></span>
                        <span><i class="far fa-star"></i></span>
                      </div>
                      <div class="price py-2">
                        <span><?php echo $item['item_price']??'0'; ?></span>
                      </div>
                      <button type="submit" class="btn btn-warning font-size-12">Add to Cart</button>
                    </div>
                  </div>
                
                
               
                </div>
                
                </div>
                <?php }, $products_shuffle) ?>
               
</section>



    <?php 
    include 'footer.php';
    ?>
</body>
</html>