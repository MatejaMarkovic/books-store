<?php


require ('dbh/dbh.classes.php');


require ('dbh/product.classes.php');





$db = new DBController();


$product = new Product($db);

