<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>J&M Books</title>
</head>
<body>
    <div class="header">
        <a href="#default" class="logo">J&M Books</a>
        <div class="header-right">
            <a href="../index.php">Home</a>
            <a class="active" href="#about">About</a>
            <?php
            if(isset($_SESSION["formuname"])){
                echo '<a href="profile.php">Profile</a>';
            }
            else if(isset($_SESSION["formemail"])){
                echo '<a href="profile.php">Profile</a>';
            }
            else{
                echo '<a href="register_page.php">Sign Out / In</a>';
            }
            ?>
        </div>
    </div>

    <?php 
    include_once '../footer.php';
    ?>
</body>
</html>