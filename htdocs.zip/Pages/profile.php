<?php 
function console_log( $data ){
    echo '<script>';
    echo 'console.log('. json_encode( $data ) .')';
    echo '</script>';
  }
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "test";
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$id = 3;
$sql = "SELECT * FROM korisnik WHERE id='$id'";
$result = $conn->query($sql);
  while($row = $result->fetch_assoc()) {
    $status = $row['status'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>J&M Books</title>
</head>
<body>
    <div class="header">
        <a href="#default" class="logo">J&M Books</a>
        <div class="header-right">
            <a href="../index.php">Home</a>
            <a href="about.php">About</a>
            <?php
            if(isset($_SESSION["formuname"])){
                echo '<a href="profile.php" class="active">Profile</a>';
            }
            else if(isset($_SESSION["formemail"])){
                echo '<a href="profile.php" class="active">Profile</a>';
            }
            else{
                echo '<a href="register_page.php">Sign Out / In</a>';
            }
            ?>
        </div>
    </div>
        <form action="../Backend/logout.php">
        <?php if ($status == 0) {
            $id= $_SESSION['id'];
            echo "<img src='uploads/profile_'.$id.'.'.'jpg'>";
    
        }else { ?>
        <img src="../profile-images/default.jpg">
        <?php }?>
        <input type="text" style="margin-top:30px;" class="form_profile" value="<?php
        if(isset($_SESSION['formuname'])){
            echo $_SESSION['formuname'];
        }
        else if(isset($_SESSION['user'])){
            echo $_SESSION['user'];
        }
        
        ?>"><br>
        <input type="email" class="form_profile" disabled  value="<?php
        if(isset($_SESSION['email'])){
            echo $_SESSION['email'];
        }
        else if(isset($_SESSION['formemail'])){
            echo $_SESSION['formemail'];
        }
        
        ?>"><br>
        <input type="password" class="form_profile" disabled value="<?php
        if(isset($_SESSION['nohash'])){
            echo $_SESSION['nohash'];
        }?>"><br>
            <button type="submit" style="background-color: #dfdfdf; " class="form_profile">Log Out</button><br>
        </form>
    <?php 
    include_once '../footer.php';
    ?>
    <?php   
            }
    ?>
</body>
</html>