<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>J&M Books</title>
</head>
<body>
    <div class="header">
        <a href="#default" class="logo">J&M Books</a>
        <div class="header-right">
            <a href="../index.php">Home</a>
            <a href="about.php">About</a>
            <?php
            if(isset($_SESSION["formuname"])){
                echo '<a href="profile.php">Profile</a>';
            }
            else if(isset($_SESSION["formemail"])){
                echo '<a href="profile.php">Profile</a>';
            }
            else{
                echo '<a href="register_page.php">Sign Out / In</a>';
            }
            ?>
        </div>
    </div>
    <div class="form">
        <form method="POST" action="../Backend/register.php">
            <input type="text" style="margin-top:30px;" class="form_profile" placeholder="Username" name="formuname"><br>
            <input type="email" class="form_profile" placeholder="E-Mail" name="formemail"><br>
            <input type="password" class="form_profile" placeholder="Password" name="formpword" minlenght="8" maxlenght="30"><br>
            <button type="submit" class="form_profile">Submit</button><br>
        </form>
    </div>
    <?php 
    include_once '../footer.php';
    ?>
    <p style="text-align:center;">Click <a href="login_page.php">here</a> if you already have an account!<p>
</body>
</html>